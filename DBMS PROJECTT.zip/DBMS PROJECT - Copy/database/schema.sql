-- Courier and Parcel Tracking System
-- Simplified College DBMS Project Schema (MySQL 8.x)
-- 4 Core Relational Tables: users, locations, parcels, tracking

-- 1. USERS TABLE
-- Holds both CUSTOMER and COMPANY accounts
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer', 'company') NOT NULL,
    phone VARCHAR(15),
    address VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. LOCATIONS TABLE
-- Regional Hubs & Distribution Facilities
CREATE TABLE IF NOT EXISTS locations (
    location_id INT AUTO_INCREMENT PRIMARY KEY,
    location_name VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100),
    latitude DECIMAL(10, 7),
    longitude DECIMAL(10, 7)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. PARCELS TABLE
-- Consignments booked by customers and managed by the company
CREATE TABLE IF NOT EXISTS parcels (
    parcel_id INT AUTO_INCREMENT PRIMARY KEY,
    tracking_number VARCHAR(30) NOT NULL UNIQUE,
    customer_id INT NOT NULL,
    sender_name VARCHAR(100) NOT NULL,
    sender_phone VARCHAR(15),
    receiver_name VARCHAR(100) NOT NULL,
    receiver_phone VARCHAR(15),
    receiver_address VARCHAR(255) NOT NULL,
    receiver_city VARCHAR(100),
    parcel_type VARCHAR(50),
    weight DECIMAL(8, 2),
    description VARCHAR(500),
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expected_delivery DATE,
    current_status VARCHAR(50) DEFAULT 'Booked',
    current_location_id INT,
    amount DECIMAL(10, 2),
    payment_status VARCHAR(30) DEFAULT 'Pending',
    INDEX idx_parcels_tracking_number (tracking_number),
    INDEX idx_parcels_customer_id (customer_id),
    INDEX idx_parcels_current_status (current_status),
    CONSTRAINT fk_parcels_customer FOREIGN KEY (customer_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_parcels_location FOREIGN KEY (current_location_id) REFERENCES locations(location_id) ON DELETE SET NULL,
    CONSTRAINT chk_parcel_weight CHECK (weight > 0),
    CONSTRAINT chk_parcel_amount CHECK (amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. TRACKING TABLE
-- Complete chronological tracking history for every parcel
CREATE TABLE IF NOT EXISTS tracking (
    tracking_id INT AUTO_INCREMENT PRIMARY KEY,
    parcel_id INT NOT NULL,
    location_id INT,
    status VARCHAR(50) NOT NULL,
    remarks VARCHAR(500),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_tracking_parcel_id (parcel_id),
    INDEX idx_tracking_updated_at (updated_at),
    CONSTRAINT fk_tracking_parcel FOREIGN KEY (parcel_id) REFERENCES parcels(parcel_id) ON DELETE CASCADE,
    CONSTRAINT fk_tracking_location FOREIGN KEY (location_id) REFERENCES locations(location_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. DATABASE VIEW: parcel_tracking_view
-- Joins parcels, users (customer), and locations into a unified view
DROP VIEW IF EXISTS parcel_tracking_view;
CREATE VIEW parcel_tracking_view AS
SELECT 
    p.parcel_id,
    p.tracking_number,
    p.customer_id,
    u.name AS customer_name,
    u.email AS customer_email,
    u.phone AS customer_phone,
    p.sender_name,
    p.sender_phone,
    p.receiver_name,
    p.receiver_phone,
    p.receiver_address,
    p.receiver_city,
    p.parcel_type,
    p.weight,
    p.description,
    p.booking_date,
    p.expected_delivery,
    p.current_status,
    p.amount,
    p.payment_status,
    l.location_id AS current_location_id,
    l.location_name AS current_location,
    l.city AS current_city
FROM parcels p
INNER JOIN users u ON p.customer_id = u.user_id
LEFT JOIN locations l ON p.current_location_id = l.location_id;
