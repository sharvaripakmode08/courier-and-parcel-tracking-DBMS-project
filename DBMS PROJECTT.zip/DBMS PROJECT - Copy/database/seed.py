"""
Seed Data Script for Simplified Courier and Parcel Tracking System.
Populates 1 Company account, 5 Customers, 5 Hub Locations, 10 Sample Parcels,
and Chronological Tracking Histories.
"""

from werkzeug.security import generate_password_hash
from database.connection import get_db_connection

def seed_database():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    try:
        # Check if users already exist
        cursor.execute("SELECT COUNT(*) AS cnt FROM users")
        if cursor.fetchone()['cnt'] > 0:
            print("[Seed] Database already seeded. Skipping.")
            return

        print("[Seed] Seeding 5 regional hub locations...")
        locations = [
            ("Mumbai Hub", "Mumbai", "Maharashtra", 19.076090, 72.877426),
            ("Pune Hub", "Pune", "Maharashtra", 18.520430, 73.856744),
            ("Nashik Hub", "Nashik", "Maharashtra", 19.997453, 73.789802),
            ("Nagpur Hub", "Nagpur", "Maharashtra", 21.145800, 79.088155),
            ("Delhi Hub", "Delhi", "Delhi", 28.613939, 77.209021)
        ]
        cursor.executemany(
            "INSERT INTO locations (location_name, city, state, latitude, longitude) VALUES (%s, %s, %s, %s, %s)",
            locations
        )

        print("[Seed] Seeding 1 Company management account...")
        company_hash = generate_password_hash("Company@123")
        cursor.execute(
            """INSERT INTO users (name, email, password_hash, role, phone, address) 
               VALUES (%s, %s, %s, 'company', %s, %s)""",
            ("SwiftCourier Operations", "company@courier.com", company_hash, "022-26540001", "Headquarters, BKC, Mumbai")
        )

        print("[Seed] Seeding 5 Customer accounts...")
        cust_hash = generate_password_hash("Customer@123")
        customers_data = [
            ("Rahul Sharma", "rahul.sharma@gmail.com", cust_hash, "9876501234", "Flat 402, Lotus Heights, Andheri West, Mumbai"),
            ("Priya Patel", "priya.patel@outlook.com", cust_hash, "9876502345", "Row House 12, Baner, Pune"),
            ("Siddharth Deshmukh", "siddharth.d@yahoo.com", cust_hash, "9876503456", "304 Green Acres, Ghodbunder Rd, Thane"),
            ("Ananya Joshi", "ananya.joshi@gmail.com", cust_hash, "9876504567", "15 Gangapur Road, Nashik"),
            ("Rohan Mehta", "rohan.mehta@gmail.com", cust_hash, "9876506789", "B-201, Civil Lines Residency, Nagpur")
        ]
        customer_ids = []
        for name, email, pw, phone, addr in customers_data:
            cursor.execute(
                """INSERT INTO users (name, email, password_hash, role, phone, address) 
                   VALUES (%s, %s, %s, 'customer', %s, %s)""",
                (name, email, pw, phone, addr)
            )
            customer_ids.append(cursor.lastrowid)

        print("[Seed] Seeding 10 Sample Parcels with tracking histories...")
        parcels_data = [
            {
                "tracking_number": "CRX202609280001",
                "cust_id": customer_ids[0],
                "sender_name": "Rahul Sharma",
                "sender_phone": "9876501234",
                "receiver_name": "Aditya Verma",
                "receiver_phone": "9819998877",
                "receiver_address": "Flat 801, Koregaon Park Towers",
                "receiver_city": "Pune",
                "parcel_type": "Express Priority",
                "weight": 2.50,
                "description": "Architectural blueprints and contract papers",
                "booking_date": "2026-09-26 10:00:00",
                "expected_delivery": "2026-09-29",
                "current_status": "Out for Delivery",
                "location_id": 2, # Pune Hub
                "amount": 250.00,
                "payment_status": "Paid",
                "history": [
                    (1, "Booked", "Consignment booked at Mumbai Hub by customer.", "2026-09-26 10:00:00"),
                    (1, "Picked Up", "Parcel picked up from shipper address.", "2026-09-26 14:30:00"),
                    (1, "In Transit", "Departed Mumbai Hub on linehaul dispatch.", "2026-09-27 06:00:00"),
                    (2, "At Hub", "Arrived at Pune Hub sorting bay.", "2026-09-27 18:00:00"),
                    (2, "Out for Delivery", "Dispatched for final mile delivery in Pune.", "2026-09-28 08:30:00")
                ]
            },
            {
                "tracking_number": "CRX202609280002",
                "cust_id": customer_ids[1],
                "sender_name": "Priya Patel",
                "sender_phone": "9876502345",
                "receiver_name": "Sunita Patil",
                "receiver_phone": "9820011223",
                "receiver_address": "Plot 24, Samarth Nagar",
                "receiver_city": "Nashik",
                "parcel_type": "Fragile Goods",
                "weight": 4.00,
                "description": "Glass optical laboratory instruments",
                "booking_date": "2026-09-27 11:20:00",
                "expected_delivery": "2026-09-30",
                "current_status": "In Transit",
                "location_id": 3, # Nashik Hub
                "amount": 380.00,
                "payment_status": "Paid",
                "history": [
                    (2, "Booked", "Parcel booked at Pune Hub.", "2026-09-27 11:20:00"),
                    (2, "Picked Up", "Secure packaging verified.", "2026-09-27 15:00:00"),
                    (3, "In Transit", "Linehaul vehicle en route to Nashik.", "2026-09-28 05:30:00")
                ]
            },
            {
                "tracking_number": "CRX202609270003",
                "cust_id": customer_ids[2],
                "sender_name": "Siddharth Deshmukh",
                "sender_phone": "9876503456",
                "receiver_name": "Dr. Sameer Godbole",
                "receiver_phone": "9830022334",
                "receiver_address": "Apollo Health Center, Ramdaspeth",
                "receiver_city": "Nagpur",
                "parcel_type": "Standard",
                "weight": 5.50,
                "description": "Medical textbooks and equipment manual",
                "booking_date": "2026-09-25 09:15:00",
                "expected_delivery": "2026-09-27",
                "current_status": "Delivered",
                "location_id": 4, # Nagpur Hub
                "amount": 450.00,
                "payment_status": "Paid",
                "history": [
                    (1, "Booked", "Registered at Mumbai Hub.", "2026-09-25 09:15:00"),
                    (1, "Picked Up", "Picked up from shipper.", "2026-09-25 13:00:00"),
                    (4, "In Transit", "Air freight transferred to Nagpur.", "2026-09-26 07:00:00"),
                    (4, "Out for Delivery", "Loaded onto delivery vehicle.", "2026-09-27 09:00:00"),
                    (4, "Delivered", "Delivered successfully. Received by Dr. Sameer Godbole.", "2026-09-27 15:30:00")
                ]
            },
            {
                "tracking_number": "CRX202609280004",
                "cust_id": customer_ids[3],
                "sender_name": "Ananya Joshi",
                "sender_phone": "9876504567",
                "receiver_name": "Manish Rao",
                "receiver_phone": "9840033445",
                "receiver_address": "Tech Park Phase 1, Hinjewadi",
                "receiver_city": "Pune",
                "parcel_type": "Electronics",
                "weight": 3.20,
                "description": "Developer test unit laptop",
                "booking_date": "2026-09-27 14:00:00",
                "expected_delivery": "2026-09-30",
                "current_status": "At Hub",
                "location_id": 3, # Nashik Hub
                "amount": 320.00,
                "payment_status": "Pending",
                "history": [
                    (3, "Booked", "Booking created online.", "2026-09-27 14:00:00"),
                    (3, "Picked Up", "Picked up by executive.", "2026-09-27 17:00:00"),
                    (3, "At Hub", "Scanned at Nashik Hub sorting center.", "2026-09-28 09:00:00")
                ]
            },
            {
                "tracking_number": "CRX202609280005",
                "cust_id": customer_ids[4],
                "sender_name": "Rohan Mehta",
                "sender_phone": "9876506789",
                "receiver_name": "Rajeshwari Iyer",
                "receiver_phone": "9850044556",
                "receiver_address": "102 Heritage Residency, Bandra",
                "receiver_city": "Mumbai",
                "parcel_type": "Apparel",
                "weight": 1.50,
                "description": "Designer festival clothes",
                "booking_date": "2026-09-28 10:30:00",
                "expected_delivery": "2026-10-01",
                "current_status": "Booked",
                "location_id": 4, # Nagpur Hub
                "amount": 180.00,
                "payment_status": "Paid",
                "history": [
                    (4, "Booked", "Consignment booked. Ready for pickup.", "2026-09-28 10:30:00")
                ]
            },
            {
                "tracking_number": "CRX202609260006",
                "cust_id": customer_ids[0],
                "sender_name": "Rahul Sharma",
                "sender_phone": "9876501234",
                "receiver_name": "Amit Deshmukh",
                "receiver_phone": "9860055667",
                "receiver_address": "88 Tilak Road, Sadashiv Peth",
                "receiver_city": "Pune",
                "parcel_type": "Documents",
                "weight": 0.80,
                "description": "Educational certificates and degree transcripts",
                "booking_date": "2026-09-24 11:00:00",
                "expected_delivery": "2026-09-26",
                "current_status": "Delivered",
                "location_id": 2, # Pune Hub
                "amount": 120.00,
                "payment_status": "Paid",
                "history": [
                    (1, "Booked", "Booking confirmed at Mumbai.", "2026-09-24 11:00:00"),
                    (1, "Picked Up", "Picked up from shipper.", "2026-09-24 14:00:00"),
                    (2, "In Transit", "Crossed expressway corridor.", "2026-09-25 08:00:00"),
                    (2, "Out for Delivery", "Assigned for morning round.", "2026-09-26 09:30:00"),
                    (2, "Delivered", "Delivered and verified.", "2026-09-26 14:00:00")
                ]
            },
            {
                "tracking_number": "CRX202609280007",
                "cust_id": customer_ids[1],
                "sender_name": "Priya Patel",
                "sender_phone": "9876502345",
                "receiver_name": "Kavita Nair",
                "receiver_phone": "9870066778",
                "receiver_address": "Plot 55, Connaught Place",
                "receiver_city": "Delhi",
                "parcel_type": "Standard",
                "weight": 2.00,
                "description": "Speciality roasted coffee beans",
                "booking_date": "2026-09-27 15:45:00",
                "expected_delivery": "2026-10-01",
                "current_status": "In Transit",
                "location_id": 1, # Mumbai Hub
                "amount": 260.00,
                "payment_status": "Pending",
                "history": [
                    (2, "Booked", "Booked at Pune.", "2026-09-27 15:45:00"),
                    (1, "In Transit", "Arrived at Mumbai linehaul gateway.", "2026-09-28 08:00:00")
                ]
            },
            {
                "tracking_number": "CRX202609250008",
                "cust_id": customer_ids[2],
                "sender_name": "Siddharth Deshmukh",
                "sender_phone": "9876503456",
                "receiver_name": "Nitin Gadve",
                "receiver_phone": "9880077889",
                "receiver_address": "Shop 4, Market Yard",
                "receiver_city": "Pune",
                "parcel_type": "Standard",
                "weight": 1.20,
                "description": "Hardware testing components",
                "booking_date": "2026-09-25 10:00:00",
                "expected_delivery": "2026-09-27",
                "current_status": "Cancelled",
                "location_id": 1,
                "amount": 140.00,
                "payment_status": "Cancelled",
                "history": [
                    (1, "Booked", "Consignment booked.", "2026-09-25 10:00:00"),
                    (1, "Cancelled", "Cancelled by customer request.", "2026-09-25 12:30:00")
                ]
            },
            {
                "tracking_number": "CRX202609280009",
                "cust_id": customer_ids[3],
                "sender_name": "Ananya Joshi",
                "sender_phone": "9876504567",
                "receiver_name": "Ramesh Gupta",
                "receiver_phone": "9890088990",
                "receiver_address": "Flat 301, Sector 18, Dwarka",
                "receiver_city": "Delhi",
                "parcel_type": "Standard",
                "weight": 3.00,
                "description": "Automotive spares",
                "booking_date": "2026-09-28 08:00:00",
                "expected_delivery": "2026-10-02",
                "current_status": "Picked Up",
                "location_id": 3, # Nashik Hub
                "amount": 310.00,
                "payment_status": "Paid",
                "history": [
                    (3, "Booked", "Booking registered.", "2026-09-28 08:00:00"),
                    (3, "Picked Up", "Picked up from shipper premise.", "2026-09-28 11:30:00")
                ]
            },
            {
                "tracking_number": "CRX202609280010",
                "cust_id": customer_ids[4],
                "sender_name": "Rohan Mehta",
                "sender_phone": "9876506789",
                "receiver_name": "Sanjay Verma",
                "receiver_phone": "9899112233",
                "receiver_address": "88 Central Avenue",
                "receiver_city": "Nagpur",
                "parcel_type": "Documents",
                "weight": 0.50,
                "description": "Legal tenancy agreement",
                "booking_date": "2026-09-28 12:00:00",
                "expected_delivery": "2026-09-29",
                "current_status": "Booked",
                "location_id": 4, # Nagpur Hub
                "amount": 90.00,
                "payment_status": "Pending",
                "history": [
                    (4, "Booked", "Registered and awaiting pickup.", "2026-09-28 12:00:00")
                ]
            }
        ]

        for p in parcels_data:
            cursor.execute("""
                INSERT INTO parcels (
                    tracking_number, customer_id, sender_name, sender_phone,
                    receiver_name, receiver_phone, receiver_address, receiver_city,
                    parcel_type, weight, description, booking_date, expected_delivery,
                    current_status, current_location_id, amount, payment_status
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                p["tracking_number"], p["cust_id"], p["sender_name"], p["sender_phone"],
                p["receiver_name"], p["receiver_phone"], p["receiver_address"], p["receiver_city"],
                p["parcel_type"], p["weight"], p["description"], p["booking_date"], p["expected_delivery"],
                p["current_status"], p["location_id"], p["amount"], p["payment_status"]
            ))
            parcel_id = cursor.lastrowid

            for loc_id, st, rem, tstamp in p["history"]:
                cursor.execute("""
                    INSERT INTO tracking (parcel_id, location_id, status, remarks, updated_at)
                    VALUES (%s, %s, %s, %s, %s)
                """, (parcel_id, loc_id, st, rem, tstamp))

        conn.commit()
        print("[Seed] Successfully seeded 1 company, 5 customers, 5 locations, 10 parcels, and tracking histories!")

    except Exception as e:
        conn.rollback()
        print(f"[Seed Error] {e}")
        raise e
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    seed_database()
