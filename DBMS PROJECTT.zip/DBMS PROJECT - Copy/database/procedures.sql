-- Stored Procedure: get_parcel_tracking
-- Input: p_tracking_id VARCHAR(30)
-- Output: Complete checkpoint tracking history for the given parcel

DROP PROCEDURE IF EXISTS get_parcel_tracking;

DELIMITER //

CREATE PROCEDURE get_parcel_tracking(IN p_tracking_id VARCHAR(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci)
BEGIN
    SELECT 
        t.tracking_id,
        p.parcel_id,
        p.tracking_id AS waybill_number,
        p.current_status AS latest_status,
        p.receiver_name,
        p.receiver_city,
        p.expected_delivery,
        t.status AS checkpoint_status,
        t.remarks,
        t.timestamp,
        l.location_id,
        l.location_name,
        l.city AS checkpoint_city,
        l.latitude,
        l.longitude,
        u.name AS updated_by_user
    FROM parcels p
    INNER JOIN tracking t ON p.parcel_id = t.parcel_id
    LEFT JOIN locations l ON t.location_id = l.location_id
    LEFT JOIN users u ON t.updated_by = u.user_id
    WHERE p.tracking_id = p_tracking_id
    ORDER BY t.timestamp ASC, t.tracking_id ASC;
END //

DELIMITER ;
