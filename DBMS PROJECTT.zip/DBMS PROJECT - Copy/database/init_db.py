import os
import sys
import mysql.connector
from config import Config
from database.seed import seed_database

def clean_sql(content):
    lines = []
    for line in content.split('\n'):
        stripped = line.strip()
        if stripped.startswith('--') or stripped.startswith('/*') or stripped.startswith('#'):
            continue
        lines.append(line)
    return '\n'.join(lines)

def execute_sql_file(cursor, filepath):
    if not os.path.exists(filepath):
        print(f"[Warning] SQL file not found: {filepath}")
        return

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    cleaned = clean_sql(content)
    statements = cleaned.split(';')
    for stmt in statements:
        stmt = stmt.strip()
        if stmt:
            cursor.execute(stmt)

def initialize_database(reset=False):
    print("=" * 60)
    print("SIMPLIFIED COURIER AND PARCEL TRACKING SYSTEM")
    print(f"Target Server: {Config.DB_HOST}:{Config.DB_PORT}")
    print(f"Target Database: {Config.DB_NAME}")
    print("=" * 60)

    try:
        # Step 1: Ensure database exists
        server_conn = mysql.connector.connect(
            host=Config.DB_HOST,
            port=Config.DB_PORT,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            charset='utf8mb4'
        )
        server_cursor = server_conn.cursor()
        print(f"[1/4] Ensuring database `{Config.DB_NAME}` exists...")
        server_cursor.execute(
            f"CREATE DATABASE IF NOT EXISTS `{Config.DB_NAME}` "
            "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
        )
        server_cursor.close()
        server_conn.close()

        # Step 2: Connect to courier_db
        conn = mysql.connector.connect(
            host=Config.DB_HOST,
            port=Config.DB_PORT,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME,
            charset='utf8mb4',
            autocommit=True
        )
        cursor = conn.cursor()

        # Clean reset of previous tables to guarantee 4-table simplified schema
        if reset:
            print("[2/4] Resetting previous tables to ensure clean 4-table architecture...")
            cursor.execute("SET FOREIGN_KEY_CHECKS = 0;")
            drop_tables = [
                "deliveries", "payments", "employees", "customers", 
                "tracking", "parcels", "locations", "users"
            ]
            for t in drop_tables:
                cursor.execute(f"DROP TABLE IF EXISTS `{t}`;")
            cursor.execute("DROP VIEW IF EXISTS `active_parcels_view`;")
            cursor.execute("DROP VIEW IF EXISTS `parcel_tracking_view`;")
            cursor.execute("DROP PROCEDURE IF EXISTS `get_parcel_tracking`;")
            cursor.execute("DROP TRIGGER IF EXISTS `trg_after_parcel_status_update`;")
            cursor.execute("SET FOREIGN_KEY_CHECKS = 1;")

        # Step 3: Run schema.sql
        print("[3/4] Creating 4 core tables (users, locations, parcels, tracking) and view...")
        schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
        execute_sql_file(cursor, schema_path)

        cursor.close()
        conn.close()

        # Step 4: Seed initial data
        print("[4/4] Seeding demonstration records (1 company, 5 customers, 5 locations, 10 parcels)...")
        seed_database()

        print("=" * 60)
        print("DATABASE INITIALIZATION COMPLETE & VERIFIED!")
        print("=" * 60)
        return True

    except Exception as e:
        print(f"[Error] Database initialization failed: {e}")
        return False

if __name__ == "__main__":
    # If run directly, run with reset=True to ensure clean simplified schema
    success = initialize_database(reset=True)
    sys.exit(0 if success else 1)
