import mysql.connector
from mysql.connector import Error
from config import Config

def get_db_connection(use_database=True):
    """
    Creates and returns a MySQL database connection using credentials from Config.
    """
    try:
        conn_params = {
            'host': Config.DB_HOST,
            'port': Config.DB_PORT,
            'user': Config.DB_USER,
            'password': Config.DB_PASSWORD,
            'charset': 'utf8mb4',
            'use_unicode': True,
            'autocommit': False
        }
        if use_database:
            conn_params['database'] = Config.DB_NAME
            
        conn = mysql.connector.connect(**conn_params)
        return conn
    except Error as e:
        print(f"[Database Error] Connection failed: {e.msg}")
        raise e

def execute_read_one(query, params=None, dictionary=True):
    """
    Executes a SELECT query and returns a single row.
    """
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=dictionary)
    try:
        cursor.execute(query, params or ())
        row = cursor.fetchone()
        return row
    finally:
        cursor.close()
        conn.close()

def execute_read_all(query, params=None, dictionary=True):
    """
    Executes a SELECT query and returns all matching rows.
    """
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=dictionary)
    try:
        cursor.execute(query, params or ())
        rows = cursor.fetchall()
        return rows
    finally:
        cursor.close()
        conn.close()

def execute_modify(query, params=None):
    """
    Executes an INSERT, UPDATE, or DELETE query and commits.
    Returns the lastrowid for INSERTs, or rowcount.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(query, params or ())
        conn.commit()
        last_id = cursor.lastrowid
        row_count = cursor.rowcount
        return last_id if last_id else row_count
    except Error as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()
