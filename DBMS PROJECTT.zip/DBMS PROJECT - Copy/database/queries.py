"""
Database Queries Module for Simplified Courier and Parcel Tracking System.
All SQL operations are clearly visible, parameterized, and organized for easy viva explanation.
Demonstrates: CREATE, INSERT, SELECT, UPDATE, DELETE, JOIN, GROUP BY, COUNT, and TRANSACTIONS.
"""

from database.connection import (
    get_db_connection,
    execute_read_one,
    execute_read_all,
    execute_modify
)

# ==========================================
# 1. USER AUTHENTICATION & PROFILE QUERIES
# ==========================================

def create_user(name, email, password_hash, role='customer', phone='', address=''):
    """
    INSERT query to register a new user (Customer or Company).
    """
    query = """
        INSERT INTO users (name, email, password_hash, role, phone, address)
        VALUES (%s, %s, %s, %s, %s, %s)
    """
    return execute_modify(query, (name, email, password_hash, role, phone, address))

def get_user_by_email(email):
    """
    SELECT query to find user credentials during login.
    """
    query = "SELECT * FROM users WHERE email = %s"
    return execute_read_one(query, (email,))

def get_user_by_id(user_id):
    """
    SELECT query by primary key.
    """
    query = "SELECT * FROM users WHERE user_id = %s"
    return execute_read_one(query, (user_id,))

def update_user_profile(user_id, name, phone, address):
    """
    UPDATE query to modify user profile details.
    """
    query = """
        UPDATE users 
        SET name = %s, phone = %s, address = %s 
        WHERE user_id = %s
    """
    return execute_modify(query, (name, phone, address, user_id))


# ==========================================
# 2. LOCATIONS (HUBS) QUERIES
# ==========================================

def get_all_locations():
    """
    SELECT query retrieving all distribution hubs ordered by city.
    """
    query = "SELECT * FROM locations ORDER BY city ASC, location_name ASC"
    return execute_read_all(query)

def get_location_by_id(location_id):
    query = "SELECT * FROM locations WHERE location_id = %s"
    return execute_read_one(query, (location_id,))


# ==========================================
# 3. PARCEL BOOKING (ACID TRANSACTION)
# ==========================================

def create_parcel_with_tracking_transaction(parcel_data, initial_remark="Consignment booked."):
    """
    ACID Transaction demonstrating START TRANSACTION, INSERT parcel,
    INSERT initial tracking checkpoint, and COMMIT / ROLLBACK.
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Step 1: Insert into parcels table
        cursor.execute("""
            INSERT INTO parcels (
                tracking_number, customer_id, sender_name, sender_phone,
                receiver_name, receiver_phone, receiver_address, receiver_city,
                parcel_type, weight, description, booking_date, expected_delivery,
                current_status, current_location_id, amount, payment_status
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), %s, 'Booked', %s, %s, %s)
        """, (
            parcel_data['tracking_number'],
            parcel_data['customer_id'],
            parcel_data['sender_name'],
            parcel_data.get('sender_phone', ''),
            parcel_data['receiver_name'],
            parcel_data.get('receiver_phone', ''),
            parcel_data['receiver_address'],
            parcel_data.get('receiver_city', ''),
            parcel_data.get('parcel_type', 'Standard'),
            parcel_data['weight'],
            parcel_data.get('description', ''),
            parcel_data['expected_delivery'],
            parcel_data.get('current_location_id'),
            parcel_data['amount'],
            parcel_data.get('payment_status', 'Pending')
        ))
        parcel_id = cursor.lastrowid

        # Step 2: Insert initial tracking history record
        cursor.execute("""
            INSERT INTO tracking (parcel_id, location_id, status, remarks, updated_at)
            VALUES (%s, %s, 'Booked', %s, NOW())
        """, (
            parcel_id,
            parcel_data.get('current_location_id'),
            initial_remark
        ))

        # Commit transaction atomically
        conn.commit()
        return parcel_id

    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()


# ==========================================
# 4. PARCEL & TRACKING QUERIES (JOIN & DQL)
# ==========================================

def get_parcel_by_tracking_number(tracking_number):
    """
    Demonstrates Relational JOIN combining:
    parcels + users (customer) + locations (current recorded hub).
    """
    query = """
        SELECT 
            p.*,
            u.name AS customer_name,
            u.email AS customer_email,
            u.phone AS customer_phone,
            u.address AS customer_address,
            l.location_name AS current_location,
            l.city AS current_city,
            l.latitude,
            l.longitude
        FROM parcels p
        INNER JOIN users u ON p.customer_id = u.user_id
        LEFT JOIN locations l ON p.current_location_id = l.location_id
        WHERE p.tracking_number = %s
    """
    return execute_read_one(query, (tracking_number.strip(),))

def get_parcel_by_id(parcel_id):
    """
    SELECT parcel details joined with customer and current location by primary key.
    """
    query = """
        SELECT 
            p.*,
            u.name AS customer_name,
            u.email AS customer_email,
            u.phone AS customer_phone,
            l.location_name AS current_location,
            l.city AS current_city
        FROM parcels p
        INNER JOIN users u ON p.customer_id = u.user_id
        LEFT JOIN locations l ON p.current_location_id = l.location_id
        WHERE p.parcel_id = %s
    """
    return execute_read_one(query, (parcel_id,))

def get_tracking_history(parcel_id):
    """
    SELECT query retrieving chronological tracking events joined with locations.
    Demonstrates ORDER BY updated_at ASC.
    """
    query = """
        SELECT 
            t.tracking_id,
            t.parcel_id,
            t.status,
            t.remarks,
            t.updated_at,
            l.location_name,
            l.city,
            l.state
        FROM tracking t
        LEFT JOIN locations l ON t.location_id = l.location_id
        WHERE t.parcel_id = %s
        ORDER BY t.updated_at ASC, t.tracking_id ASC
    """
    return execute_read_all(query, (parcel_id,))

def get_customer_parcels(customer_id, search=None, status=None):
    """
    SELECT customer's own parcels with WHERE, LIKE, and ORDER BY.
    """
    query = """
        SELECT 
            p.*,
            l.location_name AS current_location,
            l.city AS current_city
        FROM parcels p
        LEFT JOIN locations l ON p.current_location_id = l.location_id
        WHERE p.customer_id = %s
    """
    params = [customer_id]

    if search:
        query += " AND (p.tracking_number LIKE %s OR p.receiver_name LIKE %s OR p.receiver_city LIKE %s)"
        term = f"%{search}%"
        params.extend([term, term, term])

    if status and status != 'All':
        query += " AND p.current_status = %s"
        params.append(status)

    query += " ORDER BY p.booking_date DESC"
    return execute_read_all(query, tuple(params))

def get_customer_dashboard_stats(customer_id):
    """
    Demonstrates COUNT() aggregate function and conditional aggregation.
    """
    query = """
        SELECT 
            COUNT(*) AS total_parcels,
            SUM(CASE WHEN current_status = 'Booked' THEN 1 ELSE 0 END) AS booked_count,
            SUM(CASE WHEN current_status IN ('In Transit', 'At Hub') THEN 1 ELSE 0 END) AS in_transit_count,
            SUM(CASE WHEN current_status = 'Out for Delivery' THEN 1 ELSE 0 END) AS out_for_delivery_count,
            SUM(CASE WHEN current_status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_count
        FROM parcels
        WHERE customer_id = %s
    """
    return execute_read_one(query, (customer_id,))


# ==========================================
# 5. COMPANY MANAGEMENT QUERIES
# ==========================================

def get_company_parcels(search=None, status=None):
    """
    Queries the database VIEW parcel_tracking_view.
    Demonstrates using Views from application code.
    """
    query = "SELECT * FROM parcel_tracking_view WHERE 1=1"
    params = []

    if search:
        query += """ AND (
            tracking_number LIKE %s OR 
            customer_name LIKE %s OR 
            receiver_name LIKE %s OR 
            receiver_city LIKE %s
        )"""
        term = f"%{search}%"
        params.extend([term, term, term, term])

    if status and status != 'All':
        query += " AND current_status = %s"
        params.append(status)

    query += " ORDER BY booking_date DESC"
    return execute_read_all(query, tuple(params))

def get_company_dashboard_stats():
    """
    Demonstrates COUNT() and GROUP BY aggregates for the company dashboard.
    """
    query = """
        SELECT 
            COUNT(*) AS total_parcels,
            SUM(CASE WHEN current_status = 'Booked' THEN 1 ELSE 0 END) AS booked_count,
            SUM(CASE WHEN current_status IN ('In Transit', 'At Hub') THEN 1 ELSE 0 END) AS in_transit_count,
            SUM(CASE WHEN current_status = 'Out for Delivery' THEN 1 ELSE 0 END) AS out_for_delivery_count,
            SUM(CASE WHEN current_status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_count,
            SUM(CASE WHEN current_status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_count
        FROM parcels
    """
    return execute_read_one(query)

def update_parcel_tracking(parcel_id, new_status, new_location_id, remarks):
    """
    Core Company Operation:
    1. UPDATE parcels table (current_status, current_location_id)
    2. INSERT into tracking table (creates audit history record)
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # Update current status and location
        cursor.execute("""
            UPDATE parcels 
            SET current_status = %s, current_location_id = %s 
            WHERE parcel_id = %s
        """, (new_status, new_location_id, parcel_id))

        # Insert history record into tracking table
        cursor.execute("""
            INSERT INTO tracking (parcel_id, location_id, status, remarks, updated_at)
            VALUES (%s, %s, %s, %s, NOW())
        """, (parcel_id, new_location_id, new_status, remarks))

        conn.commit()
        return True
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cursor.close()
        conn.close()

def update_parcel_details(parcel_id, parcel_data):
    """
    UPDATE query to edit parcel details (receiver, expected delivery, amount, etc.)
    """
    query = """
        UPDATE parcels 
        SET receiver_name = %s,
            receiver_phone = %s,
            receiver_address = %s,
            receiver_city = %s,
            expected_delivery = %s,
            amount = %s,
            payment_status = %s
        WHERE parcel_id = %s
    """
    return execute_modify(query, (
        parcel_data['receiver_name'],
        parcel_data['receiver_phone'],
        parcel_data['receiver_address'],
        parcel_data['receiver_city'],
        parcel_data['expected_delivery'],
        parcel_data['amount'],
        parcel_data['payment_status'],
        parcel_id
    ))

def delete_parcel(parcel_id):
    """
    Demonstrates SQL DELETE operation.
    Related tracking rows are deleted automatically via ON DELETE CASCADE foreign key.
    """
    query = "DELETE FROM parcels WHERE parcel_id = %s"
    return execute_modify(query, (parcel_id,))
