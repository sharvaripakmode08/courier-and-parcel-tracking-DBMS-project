-- Database Trigger: trg_after_parcel_status_update
-- Trigger purpose:
-- Automatically audits and records status transitions into the tracking history table
-- whenever a parcel's current_status is modified.
--
-- De-duplication Mechanism:
-- To prevent double-logging when the application explicitly records a tracking checkpoint
-- with custom driver remarks, the application can set @app_skip_trigger = 1 during the transaction.
-- If @app_skip_trigger is not set or 0, this trigger guarantees zero lost history events.

DROP TRIGGER IF EXISTS trg_after_parcel_status_update;

DELIMITER //

CREATE TRIGGER trg_after_parcel_status_update
AFTER UPDATE ON parcels
FOR EACH ROW
BEGIN
    -- Check if status actually changed and trigger is not suppressed
    IF (OLD.current_status <> NEW.current_status) AND (@app_skip_trigger IS NULL OR @app_skip_trigger = 0) THEN
        INSERT INTO tracking (
            parcel_id,
            location_id,
            status,
            remarks,
            updated_by,
            timestamp
        ) VALUES (
            NEW.parcel_id,
            NEW.current_location_id,
            NEW.current_status,
            CONCAT('Automated Audit [Trigger]: Status updated from "', OLD.current_status, '" to "', NEW.current_status, '".'),
            NULL,
            NOW()
        );
    END IF;
END //

DELIMITER ;
