-- Database View: active_parcels_view
-- Joins parcels, customers, users, locations, deliveries, and employee agents

DROP VIEW IF EXISTS active_parcels_view;

CREATE VIEW active_parcels_view AS
SELECT 
    p.parcel_id,
    p.tracking_id,
    u.name AS customer_name,
    u.email AS customer_email,
    c.phone AS customer_phone,
    c.city AS sender_city,
    p.receiver_name,
    p.receiver_phone,
    p.receiver_address,
    p.receiver_city,
    p.receiver_pincode,
    p.parcel_type,
    p.weight,
    p.description,
    p.booking_date,
    p.expected_delivery,
    p.current_status,
    p.total_amount,
    p.payment_status,
    l.location_name AS current_location,
    l.city AS current_location_city,
    l.latitude AS current_latitude,
    l.longitude AS current_longitude,
    eu.name AS assigned_agent_name,
    e.phone AS assigned_agent_phone,
    d.status AS delivery_assignment_status,
    d.assigned_date AS agent_assigned_date
FROM parcels p
INNER JOIN customers c ON p.customer_id = c.customer_id
INNER JOIN users u ON c.user_id = u.user_id
LEFT JOIN locations l ON p.current_location_id = l.location_id
LEFT JOIN (
    -- Get latest delivery assignment for each parcel
    SELECT d1.*
    FROM deliveries d1
    INNER JOIN (
        SELECT parcel_id, MAX(delivery_id) AS max_deliv_id
        FROM deliveries
        GROUP BY parcel_id
    ) d2 ON d1.delivery_id = d2.max_deliv_id
) d ON p.parcel_id = d.parcel_id
LEFT JOIN employees e ON d.employee_id = e.employee_id
LEFT JOIN users eu ON e.user_id = eu.user_id;
