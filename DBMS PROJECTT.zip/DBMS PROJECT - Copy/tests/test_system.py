import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from database.connection import get_db_connection, execute_read_one, execute_read_all
from database.queries import (
    get_parcel_by_tracking_number,
    get_tracking_history,
    get_company_parcels,
    get_customer_parcels,
    create_parcel_with_tracking_transaction,
    update_parcel_tracking,
    delete_parcel
)
from services.parcel_service import generate_tracking_number, calculate_parcel_amount

class TestCourierTrackingSystem(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()

    def test_01_db_connection_and_schema(self):
        """1. Database connection check and 4-table schema verification"""
        conn = get_db_connection()
        self.assertTrue(conn.is_connected(), "MySQL connection should be active on port 3307")
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SHOW TABLES")
        tables = [list(r.values())[0] for r in cursor.fetchall()]
        cursor.close()
        conn.close()

        required_tables = ['users', 'locations', 'parcels', 'tracking']
        for tbl in required_tables:
            self.assertIn(tbl, tables, f"Table '{tbl}' must exist in MySQL courier_db database")

        # Verify database view
        view_check = execute_read_all("SELECT TABLE_NAME FROM information_schema.VIEWS WHERE TABLE_SCHEMA = 'courier_db' AND TABLE_NAME = 'parcel_tracking_view'")
        self.assertTrue(len(view_check) > 0, "View 'parcel_tracking_view' must exist in courier_db")
        print("[PASS] Test 1: MySQL 8.x database connection active and 4-table schema + View verified.")

    def test_02_customer_registration(self):
        """2. Customer registration test"""
        import time
        email = f"test_cust_{int(time.time())}@example.com"
        res = self.client.post('/register', data={
            'name': 'Test Customer',
            'email': email,
            'password': 'Password@123',
            'confirm_password': 'Password@123',
            'phone': '9876543210',
            'city': 'Mumbai',
            'pincode': '400001',
            'address': '101 Sea View Apartments'
        }, follow_redirects=True)

        self.assertEqual(res.status_code, 200)
        user = execute_read_one("SELECT * FROM users WHERE email = %s", (email,))
        self.assertIsNotNone(user, "Registered customer should exist in users table")
        self.assertEqual(user['role'], 'customer', "User role must be 'customer'")
        print("[PASS] Test 2: Customer registration succeeds and inserts record into users table.")

    def test_03_customer_login(self):
        """3. Customer login verification"""
        res = self.client.post('/login', data={
            'email': 'rahul.sharma@gmail.com',
            'password': 'Customer@123'
        }, follow_redirects=False)

        self.assertEqual(res.status_code, 302)
        self.assertIn('/customer/dashboard', res.headers['Location'])
        print("[PASS] Test 3: Customer login authenticates and redirects to /customer/dashboard.")

    def test_04_company_login(self):
        """4. Company login verification"""
        res = self.client.post('/login', data={
            'email': 'company@courier.com',
            'password': 'Company@123'
        }, follow_redirects=False)

        self.assertEqual(res.status_code, 302)
        self.assertIn('/company/dashboard', res.headers['Location'])
        print("[PASS] Test 4: Company login authenticates and redirects to /company/dashboard.")

    def test_05_parcel_booking_acid_transaction(self):
        """5. Parcel booking with ACID transaction"""
        with self.client.session_transaction() as sess:
            sess['user_id'] = 2
            sess['name'] = 'Rahul Sharma'
            sess['email'] = 'rahul.sharma@gmail.com'
            sess['role'] = 'customer'

        res = self.client.post('/customer/book', data={
            'receiver_name': 'Ananya Roy',
            'receiver_phone': '9123456789',
            'receiver_address': 'Flat 402, High Point Tower',
            'receiver_city': 'Pune',
            'parcel_type': 'Standard',
            'weight': '2.5',
            'location_id': '1',
            'description': 'Important academic project documents',
            'expected_delivery': '2026-10-02'
        }, follow_redirects=True)

        self.assertEqual(res.status_code, 200)
        # Check newly created parcel for customer 2
        parcel = execute_read_one("""
            SELECT * FROM parcels 
            WHERE customer_id = 2 AND receiver_name = 'Ananya Roy' 
            ORDER BY parcel_id DESC LIMIT 1
        """)
        self.assertIsNotNone(parcel, "Parcel must be recorded in parcels table")
        self.assertTrue(parcel['tracking_number'].startswith('CRX'), "Tracking number must start with CRX")
        self.assertEqual(parcel['current_status'], 'Booked')

        # Check tracking table checkpoint created in same transaction
        trk = execute_read_one("SELECT * FROM tracking WHERE parcel_id = %s", (parcel['parcel_id'],))
        self.assertIsNotNone(trk, "Initial checkpoint must exist in tracking table")
        self.assertEqual(trk['status'], 'Booked')
        print(f"[PASS] Test 5: Parcel booked with ACID transaction. Tracking ID: {parcel['tracking_number']}")

    def test_06_tracking_history_generated_automatically(self):
        """6. Tracking history generated automatically"""
        history = get_tracking_history(1)
        self.assertGreater(len(history), 0, "Tracking history should contain checkpoints")
        self.assertIn('status', history[0])
        self.assertIn('updated_at', history[0])
        print(f"[PASS] Test 6: Tracking history retrieved ({len(history)} checkpoints found).")

    def test_07_company_views_all_parcels(self):
        """7. Company can view all parcels"""
        with self.client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['name'] = 'FastTrack Logistics HQ'
            sess['email'] = 'company@courier.com'
            sess['role'] = 'company'

        res = self.client.get('/company/parcels')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'CRX202609280001', res.data)
        print("[PASS] Test 7: Company account can view all parcels across customers.")

    def test_08_company_updates_parcel_status(self):
        """8. Company updates parcel status and inserts checkpoint"""
        with self.client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['role'] = 'company'

        res = self.client.post('/company/parcels/1/update-tracking', data={
            'status': 'In Transit',
            'location_id': '2',
            'remarks': 'Parcel departed origin hub and in transit to Pune'
        }, follow_redirects=True)

        self.assertEqual(res.status_code, 200)
        parcel = execute_read_one("SELECT current_status, current_location_id FROM parcels WHERE parcel_id = 1")
        self.assertEqual(parcel['current_status'], 'In Transit')
        print("[PASS] Test 8: Company successfully updated parcel status to 'In Transit'.")

    def test_09_company_updates_parcel_location(self):
        """9. Company updates parcel location hub"""
        parcel = execute_read_one("SELECT current_location_id FROM parcels WHERE parcel_id = 1")
        self.assertEqual(parcel['current_location_id'], 2, "Location ID should be updated to 2")
        print("[PASS] Test 9: Company successfully updated parcel location hub to ID 2 (Pune Hub).")

    def test_10_customer_sees_updated_status(self):
        """10. Customer sees updated status on their portal"""
        with self.client.session_transaction() as sess:
            sess['user_id'] = 2
            sess['role'] = 'customer'

        res = self.client.get('/customer/parcels/1')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'In Transit', res.data)
        print("[PASS] Test 10: Customer portal displays real-time updated status 'In Transit'.")

    def test_11_public_track_page(self):
        """11. Public /track page works with tracking number"""
        res = self.client.get('/track?tracking_number=CRX202609280001')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'CRX202609280001', res.data)
        self.assertIn(b'Tracking History', res.data)
        print("[PASS] Test 11: Public /track endpoint returns parcel details and audit history.")

    def test_12_search_parcels(self):
        """12. Search parcels functionality"""
        res = get_company_parcels(search='CRX202609280001')
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0]['tracking_number'], 'CRX202609280001')

        res_city = get_company_parcels(search='Pune')
        self.assertGreater(len(res_city), 0)
        print(f"[PASS] Test 12: Search query verified for tracking number and city (found {len(res_city)} matches).")

    def test_13_update_parcel_details(self):
        """13. Update parcel details (SQL UPDATE)"""
        with self.client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['role'] = 'company'

        res = self.client.post('/company/parcels/1/edit', data={
            'receiver_name': 'Rahul Sharma Updated',
            'receiver_phone': '9820098200',
            'receiver_address': 'Flat 12B, Bandra West',
            'receiver_city': 'Mumbai',
            'expected_delivery': '2026-10-05',
            'amount': '220.00',
            'payment_status': 'Paid'
        }, follow_redirects=True)

        self.assertEqual(res.status_code, 200)
        p = execute_read_one("SELECT receiver_name, amount, payment_status FROM parcels WHERE parcel_id = 1")
        self.assertEqual(p['receiver_name'], 'Rahul Sharma Updated')
        self.assertEqual(float(p['amount']), 220.00)
        self.assertEqual(p['payment_status'], 'Paid')
        print("[PASS] Test 13: SQL UPDATE statement executed and persisted for parcel details.")

    def test_14_delete_parcel(self):
        """14. Delete parcel (SQL DELETE with CASCADE/Transaction)"""
        # Create a temp parcel
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO parcels (tracking_number, customer_id, sender_name, receiver_name, receiver_address, weight, amount)
            VALUES ('CRX_TEST_DELETE_99', 2, 'Sender', 'Receiver', 'Address', 1.0, 100.0)
        """)
        del_id = cur.lastrowid
        cur.execute("""
            INSERT INTO tracking (parcel_id, location_id, status, remarks, updated_at)
            VALUES (%s, 1, 'Booked', 'Initial checkpoint before deletion', NOW())
        """, (del_id,))
        conn.commit()
        cur.close()
        conn.close()

        with self.client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['role'] = 'company'

        res = self.client.post(f'/company/parcels/{del_id}/delete', follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # Verify deletion in MySQL
        check_parcel = execute_read_one("SELECT * FROM parcels WHERE parcel_id = %s", (del_id,))
        self.assertIsNone(check_parcel, "Deleted parcel should not exist in parcels table")
        check_tracking = execute_read_all("SELECT * FROM tracking WHERE parcel_id = %s", (del_id,))
        self.assertEqual(len(check_tracking), 0, "Associated tracking records should be removed")
        print("[PASS] Test 14: SQL DELETE successfully removes parcel and cascade cleans tracking records.")

    def test_15_view_query(self):
        """15. Database View query verification"""
        rows = execute_read_all("SELECT tracking_number, customer_name, current_status FROM parcel_tracking_view LIMIT 5")
        self.assertGreater(len(rows), 0, "View should return rows")
        self.assertIn('customer_name', rows[0])
        print(f"[PASS] Test 15: parcel_tracking_view query verified ({len(rows)} rows queried).")

    def test_16_join_query_verification(self):
        """16. Multi-table Relational JOIN query"""
        query = """
            SELECT 
                p.tracking_number, 
                u.name AS customer_name, 
                p.receiver_name, 
                COALESCE(l.location_name, 'Origin Hub') AS hub_name
            FROM parcels p
            INNER JOIN users u ON p.customer_id = u.user_id
            LEFT JOIN locations l ON p.current_location_id = l.location_id
            LIMIT 5
        """
        rows = execute_read_all(query)
        self.assertGreater(len(rows), 0, "JOIN query must return rows")
        self.assertIn('customer_name', rows[0])
        self.assertIn('hub_name', rows[0])
        print(f"[PASS] Test 16: Multi-table JOIN (parcels + users + locations) verified.")

    def test_17_groupby_aggregate_query(self):
        """17. GROUP BY and COUNT() aggregate query"""
        query = """
            SELECT 
                current_status,
                COUNT(*) AS total_count,
                ROUND(SUM(amount), 2) AS total_revenue,
                ROUND(AVG(weight), 2) AS avg_weight
            FROM parcels
            GROUP BY current_status
        """
        rows = execute_read_all(query)
        self.assertGreater(len(rows), 0, "GROUP BY query must return status breakdown")
        for r in rows:
            self.assertIn('total_count', r)
            self.assertIn('total_revenue', r)
        print(f"[PASS] Test 17: GROUP BY aggregate query with COUNT(*), SUM(), AVG() verified.")

    def test_18_transaction_rollback(self):
        """18. Transaction rollback verification on database error"""
        conn = get_db_connection()
        cursor = conn.cursor()
        failed = False
        fake_tracking_no = "CRX_ROLLBACK_TEST_999"

        try:
            # Step 1: Insert into parcels
            cursor.execute("""
                INSERT INTO parcels (tracking_number, customer_id, sender_name, receiver_name, receiver_address, weight, amount)
                VALUES (%s, 2, 'Sender', 'Receiver', 'Address', 1.0, 100.0)
            """, (fake_tracking_no,))

            # Step 2: Deliberately violate Foreign Key in tracking table (non-existent location_id)
            cursor.execute("""
                INSERT INTO tracking (parcel_id, location_id, status, remarks, updated_at)
                VALUES (%s, 99999, 'Booked', 'Intentional FK violation', NOW())
            """, (cursor.lastrowid,))

            conn.commit()
        except Exception:
            conn.rollback()
            failed = True
        finally:
            cursor.close()
            conn.close()

        self.assertTrue(failed, "Transaction must fail and raise exception on constraint violation")

        # Verify rollback: fake_tracking_no must NOT exist in parcels table
        check = execute_read_one("SELECT * FROM parcels WHERE tracking_number = %s", (fake_tracking_no,))
        self.assertIsNone(check, "Rollback must ensure no orphaned parcel record was committed")
        print("[PASS] Test 18: ACID Transaction Rollback verified (zero orphaned records after failure).")

if __name__ == '__main__':
    unittest.main(verbosity=2)
