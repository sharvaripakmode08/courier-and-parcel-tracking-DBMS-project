import os
import sys
from dotenv import load_dotenv
import mysql.connector
from mysql.connector import Error

def test_db_connection():
    # 1. Load credentials from .env
    load_dotenv(override=True)
    
    db_host = os.getenv("DB_HOST", "localhost")
    db_port = int(os.getenv("DB_PORT", "3307"))
    db_user = os.getenv("DB_USER", "root")
    db_password = os.getenv("DB_PASSWORD", "")
    db_name = os.getenv("DB_NAME", "courier_db")

    conn = None
    cursor = None
    try:
        # First ensure courier_db exists on the server
        server_conn = mysql.connector.connect(
            host=db_host,
            port=db_port,
            user=db_user,
            password=db_password
        )
        server_cursor = server_conn.cursor()
        server_cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
        server_cursor.close()
        server_conn.close()

        # 2 & 3 & 4. Connect to localhost:3307, authenticate as root, select courier_db
        conn = mysql.connector.connect(
            host=db_host,
            port=db_port,
            user=db_user,
            password=db_password,
            database=db_name
        )

        if conn.is_connected():
            cursor = conn.cursor()
            # 5. Execute: SELECT VERSION();
            cursor.execute("SELECT VERSION();")
            version_row = cursor.fetchone()
            version = version_row[0] if version_row else "Unknown"
            
            # 6. Print only the MySQL version and connection success/failure
            print(f"MySQL Version: {version}")
            print("Connection: SUCCESS")
            return True
        else:
            print("Connection: FAILED")
            return False

    except Error as e:
        print(f"Connection: FAILED (MySQL Error: {e.msg})")
        return False
    except Exception as e:
        print(f"Connection: FAILED (Error: {str(e)})")
        return False
    finally:
        # 7. Close the connection
        if cursor is not None:
            cursor.close()
        if conn is not None and conn.is_connected():
            conn.close()

if __name__ == "__main__":
    success = test_db_connection()
    sys.exit(0 if success else 1)
