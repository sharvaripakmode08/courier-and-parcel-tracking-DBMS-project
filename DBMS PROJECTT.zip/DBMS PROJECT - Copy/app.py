import os
from flask import Flask, render_template, redirect, url_for, session, request
from config import Config
from routes.auth import auth_bp
from routes.customer import customer_bp
from routes.company import company_bp
from routes.tracking import tracking_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Register blueprints (Only Customer, Company, Auth, and Tracking)
    app.register_blueprint(auth_bp)
    app.register_blueprint(customer_bp)
    app.register_blueprint(company_bp)
    app.register_blueprint(tracking_bp)

    @app.context_processor
    def inject_global_context():
        return {
            'current_user': {
                'id': session.get('user_id'),
                'name': session.get('name', 'Guest'),
                'email': session.get('email'),
                'role': session.get('role')
            },
            'active_path': request.path
        }

    @app.route('/')
    def index():
        if 'user_id' in session:
            if session.get('role') == 'company':
                return redirect(url_for('company.dashboard'))
            return redirect(url_for('customer.dashboard'))
        return render_template('index.html')

    # Error Handlers
    @app.errorhandler(403)
    def forbidden_error(error):
        return render_template('errors/403.html'), 403

    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('errors/404.html'), 404

    @app.errorhandler(500)
    def internal_error(error):
        return render_template('errors/500.html'), 500

    return app

app = create_app()

if __name__ == '__main__':
    # Local dev server on port 5000
    app.run(host='127.0.0.1', port=5000, debug=True)
