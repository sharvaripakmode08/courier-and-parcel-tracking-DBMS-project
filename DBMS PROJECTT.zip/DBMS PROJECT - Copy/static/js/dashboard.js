// TraceLogistics - Chart.js Operational Visualizations
function initDashboardCharts(chartData) {
    if (typeof Chart === 'undefined') return;

    // 1. Status Distribution Flow Chart
    const statusCtx = document.getElementById('statusChart');
    if (statusCtx && chartData.status_distribution) {
        const labels = chartData.status_distribution.map(d => d.current_status);
        const counts = chartData.status_distribution.map(d => d.count);
        
        const backgroundColors = labels.map(status => {
            if (status === 'Delivered') return '#10b981';
            if (status === 'Out for Delivery') return '#2563eb';
            if (status === 'In Transit') return '#0284c7';
            if (status === 'At Hub') return '#f59e0b';
            if (status === 'Booked') return '#94a3b8';
            return '#ef4444';
        });

        new Chart(statusCtx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Parcels',
                    data: counts,
                    backgroundColor: backgroundColors,
                    borderRadius: 6,
                    maxBarThickness: 38
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#f1f5f9' },
                        ticks: { stepSize: 1 }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    }

    // 2. Hub Throughput / City Volume
    const cityCtx = document.getElementById('cityChart');
    if (cityCtx && chartData.city_distribution) {
        const labels = chartData.city_distribution.map(d => d.receiver_city);
        const counts = chartData.city_distribution.map(d => d.count);

        new Chart(cityCtx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: counts,
                    backgroundColor: [
                        '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#bfdbfe', '#e2e8f0'
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { boxWidth: 12, font: { size: 11 } }
                    }
                },
                cutout: '70%'
            }
        });
    }
}
