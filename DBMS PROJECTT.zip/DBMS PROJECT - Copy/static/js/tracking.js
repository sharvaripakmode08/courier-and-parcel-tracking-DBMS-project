// Leaflet.js Interactive Tracking Map
function initTrackingMap(origin, dest, current, originName, destName, currentStatus) {
    const mapElement = document.getElementById('tracking-map');
    if (!mapElement || typeof L === 'undefined') return;

    // Center map around current position or default
    const map = L.map('tracking-map', {
        zoomControl: true,
        scrollWheelZoom: false
    }).setView([current[0], current[1]], 7);

    // OpenStreetMap high-definition tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 18
    }).addTo(map);

    // Custom Icons
    const originIcon = L.divIcon({
        className: 'custom-map-pin origin-pin',
        html: '<div style="background-color:#64748b; color:white; border-radius:50%; width:26px; height:26px; display:flex; align-items:center; justify-content:center; border:2px solid white; box-shadow:0 2px 5px rgba(0,0,0,0.3);"><i class="bi bi-box-seam" style="font-size:13px;"></i></div>',
        iconSize: [26, 26],
        iconAnchor: [13, 13]
    });

    const destIcon = L.divIcon({
        className: 'custom-map-pin dest-pin',
        html: '<div style="background-color:#10b981; color:white; border-radius:50%; width:26px; height:26px; display:flex; align-items:center; justify-content:center; border:2px solid white; box-shadow:0 2px 5px rgba(0,0,0,0.3);"><i class="bi bi-geo-alt-fill" style="font-size:13px;"></i></div>',
        iconSize: [26, 26],
        iconAnchor: [13, 13]
    });

    const truckIcon = L.divIcon({
        className: 'custom-map-pin truck-pin',
        html: '<div style="background-color:#2563eb; color:white; border-radius:50%; width:34px; height:34px; display:flex; align-items:center; justify-content:center; border:3px solid white; box-shadow:0 3px 8px rgba(37,99,235,0.5);"><i class="bi bi-truck" style="font-size:16px;"></i></div>',
        iconSize: [34, 34],
        iconAnchor: [17, 17]
    });

    // Markers
    const originMarker = L.marker([origin[0], origin[1]], { icon: originIcon })
        .addTo(map)
        .bindPopup(`<strong>Origin Facility</strong><br>${originName || 'Origin Hub'}`);

    const destMarker = L.marker([dest[0], dest[1]], { icon: destIcon })
        .addTo(map)
        .bindPopup(`<strong>Destination</strong><br>${destName || 'Recipient Address'}`);

    const currentMarker = L.marker([current[0], current[1]], { icon: truckIcon })
        .addTo(map)
        .bindPopup(`<strong>Current Location</strong><br>Status: ${currentStatus || 'In Transit'}`)
        .openPopup();

    // Route Polyline
    const routeCoords = [
        [origin[0], origin[1]],
        [current[0], current[1]],
        [dest[0], dest[1]]
    ];

    const polyline = L.polyline(routeCoords, {
        color: '#2563eb',
        weight: 4,
        opacity: 0.8,
        dashArray: '8, 8',
        lineCap: 'round'
    }).addTo(map);

    // Fit map bounds to show complete corridor
    const group = new L.featureGroup([originMarker, destMarker, currentMarker]);
    map.fitBounds(group.getBounds().pad(0.2));
}
