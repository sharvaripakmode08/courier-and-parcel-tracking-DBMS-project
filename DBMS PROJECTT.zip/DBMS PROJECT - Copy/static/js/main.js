// TraceLogistics - Core Client JS
document.addEventListener('DOMContentLoaded', () => {
    // 1. Mobile Sidebar Toggle
    const toggleBtn = document.getElementById('sidebar-toggle');
    const sidebar = document.querySelector('.sidebar');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
        });
    }

    // 2. Global Shortcut: Ctrl+K or Cmd+K focuses search
    const globalSearch = document.getElementById('global-search-input');
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            if (globalSearch) {
                globalSearch.focus();
                globalSearch.select();
            }
        }
    });

    if (globalSearch) {
        globalSearch.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const term = globalSearch.value.trim();
                if (term) {
                    window.location.href = `/track?id=${encodeURIComponent(term)}`;
                }
            }
        });
    }

    // 3. Auto dismiss alert messages after 5 seconds
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert-dismissible');
        alerts.forEach(alert => {
            if (window.bootstrap && bootstrap.Alert) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        });
    }, 5000);
});

// Helper for copying text to clipboard
function copyToClipboard(text, elem) {
    navigator.clipboard.writeText(text).then(() => {
        const originalText = elem.innerHTML;
        elem.innerHTML = '<i class="bi bi-check2"></i> Copied!';
        setTimeout(() => {
            elem.innerHTML = originalText;
        }, 2000);
    });
}
