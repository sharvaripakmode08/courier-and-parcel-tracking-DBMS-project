// TraceLogistics - Booking Form Live Tariff Calculations
document.addEventListener('DOMContentLoaded', () => {
    const weightInput = document.getElementById('weight-input');
    const categoryRadios = document.querySelectorAll('input[name="parcel_type"]');
    const summaryWeight = document.getElementById('summary-weight');
    const summaryBaseRate = document.getElementById('summary-base-rate');
    const summaryTotal = document.getElementById('summary-total-amount');

    const BASE_RATES = {
        'Standard Ground': 100.0,
        'Express Priority': 220.0,
        'Same-Day Courier': 380.0,
        'Fragile Goods': 260.0,
        'Heavy Cargo': 450.0,
        'Documents': 80.0,
        'Electronics': 200.0,
        'Apparel': 120.0
    };

    const RATE_PER_KG = {
        'Standard Ground': 40.0,
        'Express Priority': 65.0,
        'Same-Day Courier': 90.0,
        'Fragile Goods': 75.0,
        'Heavy Cargo': 55.0,
        'Documents': 30.0,
        'Electronics': 60.0,
        'Apparel': 40.0
    };

    function recalculate() {
        if (!weightInput || !summaryTotal) return;

        let weight = parseFloat(weightInput.value) || 1.0;
        if (weight <= 0) weight = 1.0;

        let selectedType = 'Standard Ground';
        categoryRadios.forEach(radio => {
            if (radio.checked) selectedType = radio.value;
        });

        const base = BASE_RATES[selectedType] || 120.0;
        const perKg = RATE_PER_KG[selectedType] || 45.0;
        const total = base + (weight * perKg);

        if (summaryWeight) summaryWeight.textContent = weight.toFixed(2) + ' kg';
        if (summaryBaseRate) summaryBaseRate.textContent = '₹' + base.toFixed(2);
        if (summaryTotal) summaryTotal.textContent = '₹' + total.toFixed(2);
    }

    if (weightInput) {
        weightInput.addEventListener('input', recalculate);
    }
    categoryRadios.forEach(r => r.addEventListener('change', recalculate));

    // Initial calculation on page load
    recalculate();
});
