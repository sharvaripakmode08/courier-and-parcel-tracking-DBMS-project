from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from utils.auth import login_required, role_required
from database.queries import (
    get_all_locations,
    get_company_parcels,
    get_company_dashboard_stats,
    get_parcel_by_id,
    get_tracking_history,
    update_parcel_tracking,
    update_parcel_details,
    delete_parcel,
    create_parcel_with_tracking_transaction
)
from database.connection import get_db_connection, execute_read_all, execute_read_one

company_bp = Blueprint('company', __name__, url_prefix='/company')

@company_bp.before_request
@login_required
@role_required('company')
def check_company_role():
    pass

@company_bp.route('/dashboard')
def dashboard():
    stats = get_company_dashboard_stats()
    all_parcels = get_company_parcels()
    return render_template('company/dashboard.html', stats=stats, parcels=all_parcels[:8])

@company_bp.route('/parcels')
def parcels():
    search = request.args.get('search', '').strip()
    status = request.args.get('status', 'All')

    all_parcels = get_company_parcels(search=search, status=status)
    return render_template('company/parcels.html', parcels=all_parcels, search=search, current_status=status)

@company_bp.route('/parcels/<int:id>')
def parcel_details(id):
    parcel = get_parcel_by_id(id)
    if not parcel:
        flash("Parcel not found.", "danger")
        return redirect(url_for('company.parcels'))

    history = get_tracking_history(id)
    return render_template('company/parcel_details.html', parcel=parcel, history=history)

@company_bp.route('/update-tracking', methods=['GET', 'POST'])
def update_tracking_redirect():
    parcel_id = request.args.get('parcel_id')
    if parcel_id:
        return redirect(url_for('company.update_tracking', id=parcel_id))
    flash("Please select a parcel to update its tracking status.", "info")
    return redirect(url_for('company.parcels'))

@company_bp.route('/parcels/<int:id>/update-tracking', methods=['GET', 'POST'])
def update_tracking(id):
    parcel = get_parcel_by_id(id)
    if not parcel:
        flash("Parcel not found.", "danger")
        return redirect(url_for('company.parcels'))

    locations = get_all_locations()

    if request.method == 'POST':
        new_status = request.form.get('status')
        location_id = request.form.get('location_id')
        remarks = request.form.get('remarks', '').strip()

        if not new_status:
            flash("Status is required.", "danger")
            return render_template('company/update_tracking.html', parcel=parcel, locations=locations)

        loc_id = int(location_id) if location_id else None

        try:
            update_parcel_tracking(
                parcel_id=id,
                new_status=new_status,
                new_location_id=loc_id,
                remarks=remarks or f"Status updated to {new_status}."
            )
            flash(f"Tracking updated successfully! Status is now '{new_status}'.", "success")
            return redirect(url_for('company.parcel_details', id=id))
        except Exception as e:
            flash(f"Failed to update tracking: {str(e)}", "danger")

    return render_template('company/update_tracking.html', parcel=parcel, locations=locations)

@company_bp.route('/parcels/<int:id>/edit', methods=['GET', 'POST'])
def edit_parcel(id):
    parcel = get_parcel_by_id(id)
    if not parcel:
        flash("Parcel not found.", "danger")
        return redirect(url_for('company.parcels'))

    if request.method == 'POST':
        receiver_name = request.form.get('receiver_name', '').strip()
        receiver_phone = request.form.get('receiver_phone', '').strip()
        receiver_address = request.form.get('receiver_address', '').strip()
        receiver_city = request.form.get('receiver_city', '').strip()
        expected_delivery = request.form.get('expected_delivery')
        amount = float(request.form.get('amount', 0))
        payment_status = request.form.get('payment_status', 'Pending')

        parcel_data = {
            'receiver_name': receiver_name,
            'receiver_phone': receiver_phone,
            'receiver_address': receiver_address,
            'receiver_city': receiver_city,
            'expected_delivery': expected_delivery,
            'amount': amount,
            'payment_status': payment_status
        }

        try:
            update_parcel_details(id, parcel_data)
            flash("Parcel details updated successfully.", "success")
            return redirect(url_for('company.parcel_details', id=id))
        except Exception as e:
            flash(f"Update failed: {str(e)}", "danger")

    return render_template('company/edit_parcel.html', parcel=parcel)

@company_bp.route('/parcels/<int:id>/delete', methods=['POST'])
def delete_parcel_route(id):
    """
    Demonstrates SQL DELETE query from Python.
    """
    try:
        delete_parcel(id)
        flash("Parcel successfully deleted from MySQL database.", "info")
    except Exception as e:
        flash(f"Failed to delete parcel: {str(e)}", "danger")

    return redirect(url_for('company.parcels'))

# ==========================================
# 13. REPORT / DBMS DEMONSTRATION PAGE
# ==========================================
@company_bp.route('/dbms')
def dbms_demo():
    """
    Dedicated College DBMS demonstration page for company account.
    """
    return render_template('company/dbms.html')

@company_bp.route('/dbms/run-demo', methods=['POST'])
def run_dbms_demo():
    concept = request.form.get('concept', '')
    conn = get_db_connection()
    cur = conn.cursor(dictionary=True)

    try:
        if concept == 'create':
            # Inspect table metadata from INFORMATION_SCHEMA
            cur.execute("""
                SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_KEY 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = 'courier_db' AND TABLE_NAME = 'parcels'
                ORDER BY ORDINAL_POSITION LIMIT 8;
            """)
            output = cur.fetchall()
            result = {
                "operation": "CREATE TABLE & Schema Definition",
                "purpose": "Demonstrates table creation with primary keys, foreign keys, and check constraints.",
                "sql": "CREATE TABLE parcels (parcel_id INT AUTO_INCREMENT PRIMARY KEY, tracking_number VARCHAR(30) UNIQUE, customer_id INT, ...);",
                "output": output
            }

        elif concept == 'insert':
            # Insert a demonstration tracking event
            cur.execute("""
                INSERT INTO tracking (parcel_id, location_id, status, remarks, updated_at)
                VALUES (1, 1, 'In Transit', 'DBMS Live Demonstration Checkpoint', NOW());
            """)
            conn.commit()
            cur.execute("SELECT * FROM tracking WHERE remarks = 'DBMS Live Demonstration Checkpoint' ORDER BY tracking_id DESC LIMIT 1;")
            row = cur.fetchone()
            result = {
                "operation": "INSERT Query with Parameterization",
                "purpose": "Demonstrates inserting new record into tracking table with immediate commit.",
                "sql": "INSERT INTO tracking (parcel_id, location_id, status, remarks, updated_at) VALUES (%s, %s, %s, %s, NOW());",
                "output": [row] if row else []
            }

        elif concept == 'select':
            # SELECT parcels with WHERE and ORDER BY
            cur.execute("""
                SELECT parcel_id, tracking_number, receiver_name, receiver_city, current_status, amount 
                FROM parcels 
                WHERE current_status != 'Cancelled'
                ORDER BY booking_date DESC 
                LIMIT 5;
            """)
            output = cur.fetchall()
            result = {
                "operation": "SELECT with WHERE and ORDER BY",
                "purpose": "Demonstrates querying filtered records sorted chronologically.",
                "sql": "SELECT parcel_id, tracking_number, receiver_name, receiver_city, current_status, amount FROM parcels WHERE current_status != 'Cancelled' ORDER BY booking_date DESC LIMIT 5;",
                "output": output
            }

        elif concept == 'update':
            # UPDATE parcel status
            cur.execute("""
                UPDATE parcels 
                SET current_status = 'In Transit' 
                WHERE parcel_id = 1;
            """)
            conn.commit()
            cur.execute("SELECT parcel_id, tracking_number, current_status FROM parcels WHERE parcel_id = 1;")
            row = cur.fetchone()
            result = {
                "operation": "UPDATE Statement",
                "purpose": "Demonstrates modifying parcel status and persisting the change.",
                "sql": "UPDATE parcels SET current_status = 'In Transit' WHERE parcel_id = 1;",
                "output": [row] if row else []
            }

        elif concept == 'delete':
            # Demonstrates DELETE query safely using a temporary test parcel
            cur.execute("""
                INSERT INTO parcels (tracking_number, customer_id, sender_name, receiver_name, receiver_address, weight, amount)
                VALUES ('CRX_DELETE_TEST', 2, 'Test Shipper', 'Test Receiver', 'Address', 1.0, 50.0);
            """)
            del_id = cur.lastrowid
            conn.commit()

            cur.execute("DELETE FROM parcels WHERE parcel_id = %s;", (del_id,))
            conn.commit()

            cur.execute("SELECT * FROM parcels WHERE parcel_id = %s;", (del_id,))
            output = cur.fetchall()
            result = {
                "operation": "DELETE Statement",
                "purpose": "Demonstrates deleting a record from MySQL (zero rows returned after deletion).",
                "sql": f"DELETE FROM parcels WHERE parcel_id = {del_id};",
                "output": output if output else [{"status": "Record deleted successfully. 0 rows remain."}]
            }

        elif concept == 'join':
            # Multi-table relational JOIN
            cur.execute("""
                SELECT 
                    p.tracking_number,
                    u.name AS customer_name,
                    p.receiver_name,
                    p.receiver_city,
                    p.current_status,
                    COALESCE(l.location_name, 'Origin Hub') AS current_location
                FROM parcels p
                INNER JOIN users u ON p.customer_id = u.user_id
                LEFT JOIN locations l ON p.current_location_id = l.location_id
                ORDER BY p.booking_date DESC 
                LIMIT 5;
            """)
            output = cur.fetchall()
            result = {
                "operation": "Relational JOIN (parcels + users + locations)",
                "purpose": "Combines 3 tables to display customer name and hub location for each parcel.",
                "sql": "SELECT p.tracking_number, u.name AS customer_name, p.receiver_name, l.location_name FROM parcels p INNER JOIN users u ON p.customer_id = u.user_id LEFT JOIN locations l ON p.current_location_id = l.location_id;",
                "output": output
            }

        elif concept == 'groupby':
            # GROUP BY and COUNT()
            cur.execute("""
                SELECT 
                    current_status,
                    COUNT(*) AS total_parcels,
                    ROUND(SUM(amount), 2) AS total_revenue,
                    ROUND(AVG(weight), 2) AS avg_weight_kg
                FROM parcels
                GROUP BY current_status
                ORDER BY total_parcels DESC;
            """)
            output = cur.fetchall()
            result = {
                "operation": "GROUP BY with COUNT(), SUM(), AVG()",
                "purpose": "Aggregates parcel counts and revenue grouped by transit status.",
                "sql": "SELECT current_status, COUNT(*), SUM(amount), AVG(weight) FROM parcels GROUP BY current_status ORDER BY COUNT(*) DESC;",
                "output": output
            }

        elif concept == 'transaction':
            # ACID Transaction Commit
            import time
            tx_num = f"CRX_TX_{int(time.time()*1000)%1000000}"
            cur.execute("""
                INSERT INTO parcels (tracking_number, customer_id, sender_name, receiver_name, receiver_address, weight, amount, current_status)
                VALUES (%s, 2, 'TX Sender', 'TX Receiver', 'TX Address', 2.0, 150.0, 'Booked');
            """, (tx_num,))
            new_pid = cur.lastrowid

            cur.execute("""
                INSERT INTO tracking (parcel_id, location_id, status, remarks, updated_at)
                VALUES (%s, 1, 'Booked', 'Initial transaction commit demo', NOW());
            """, (new_pid,))
            conn.commit()

            cur.execute("""
                SELECT p.tracking_number, p.current_status, t.status AS tracking_status, t.remarks 
                FROM parcels p 
                JOIN tracking t ON p.parcel_id = t.parcel_id 
                WHERE p.parcel_id = %s;
            """, (new_pid,))
            output = cur.fetchall()
            result = {
                "operation": "ACID Transaction (COMMIT)",
                "purpose": "Atomically inserts parcel + tracking and commits together.",
                "sql": "START TRANSACTION; INSERT INTO parcels ...; INSERT INTO tracking ...; COMMIT;",
                "output": output
            }

        elif concept == 'view':
            # Database View: parcel_tracking_view
            cur.execute("SELECT tracking_number, customer_name, receiver_name, current_status, current_location FROM parcel_tracking_view LIMIT 5;")
            output = cur.fetchall()
            result = {
                "operation": "Database VIEW (parcel_tracking_view)",
                "purpose": "Queries pre-defined relational view combining parcels, customers, and locations.",
                "sql": "SELECT tracking_number, customer_name, receiver_name, current_status, current_location FROM parcel_tracking_view LIMIT 5;",
                "output": output
            }

        return jsonify({"success": True, "result": result})

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        cur.close()
        conn.close()
