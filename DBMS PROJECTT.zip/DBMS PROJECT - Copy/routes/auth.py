import re
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from werkzeug.security import check_password_hash, generate_password_hash
from database.queries import (
    get_user_by_email,
    create_user
)

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        if session.get('role') == 'company':
            return redirect(url_for('company.dashboard'))
        return redirect(url_for('customer.dashboard'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not email or not password:
            flash("Please enter both email and password.", "danger")
            return render_template('login.html', email=email)

        user = get_user_by_email(email)
        if not user or not check_password_hash(user['password_hash'], password):
            flash("Invalid email or password. Please try again.", "danger")
            return render_template('login.html', email=email)

        # Store session
        session.clear()
        session['user_id'] = user['user_id']
        session['name'] = user['name']
        session['email'] = user['email']
        session['role'] = user['role']

        flash(f"Welcome back, {user['name']}!", "success")

        if user['role'] == 'company':
            return redirect(url_for('company.dashboard'))
        return redirect(url_for('customer.dashboard'))

    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('customer.dashboard'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        phone = request.form.get('phone', '').strip()
        address = request.form.get('address', '').strip()

        # Validation
        errors = []
        if not name or len(name) < 2:
            errors.append("Please enter a valid full name.")
        if not email or not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            errors.append("Please provide a valid email address.")
        if len(password) < 6:
            errors.append("Password must be at least 6 characters.")
        if password != confirm_password:
            errors.append("Passwords do not match.")
        if not phone or len(phone) < 10:
            errors.append("Please enter a valid 10-digit mobile number.")
        if not address:
            errors.append("Address is required.")

        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template('register.html', form_data=request.form)

        # Check existing user
        if get_user_by_email(email):
            flash("An account with this email address already exists. Please sign in.", "warning")
            return redirect(url_for('auth.login'))

        city = request.form.get('city', '').strip()
        pincode = request.form.get('pincode', '').strip()
        full_address = address
        if city and city.lower() not in address.lower():
            full_address += f", {city}"
        if pincode and pincode not in address:
            full_address += f" - {pincode}"

        # Insert user with role 'customer'
        password_hash = generate_password_hash(password)
        try:
            user_id = create_user(
                name=name,
                email=email,
                password_hash=password_hash,
                role='customer',
                phone=phone,
                address=full_address
            )
            # Automatic login
            session.clear()
            session['user_id'] = user_id
            session['name'] = name
            session['email'] = email
            session['role'] = 'customer'

            flash("Account registered successfully! Welcome to SwiftCourier.", "success")
            return redirect(url_for('customer.dashboard'))
        except Exception as e:
            flash(f"Registration failed: {str(e)}", "danger")
            return render_template('register.html', form_data=request.form)

    return render_template('register.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    flash("You have been signed out.", "info")
    return redirect(url_for('auth.login'))
