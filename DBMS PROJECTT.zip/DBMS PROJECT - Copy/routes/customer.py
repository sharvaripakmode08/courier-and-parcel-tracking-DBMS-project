import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from utils.auth import login_required, role_required
from database.queries import (
    get_user_by_id,
    update_user_profile,
    get_all_locations,
    get_customer_parcels,
    get_customer_dashboard_stats,
    get_parcel_by_id,
    get_tracking_history,
    create_parcel_with_tracking_transaction
)
from services.parcel_service import generate_tracking_number, calculate_parcel_amount

customer_bp = Blueprint('customer', __name__, url_prefix='/customer')

@customer_bp.before_request
@login_required
@role_required('customer')
def check_customer_role():
    pass

@customer_bp.route('/dashboard')
def dashboard():
    user_id = session.get('user_id')
    user = get_user_by_id(user_id)
    stats = get_customer_dashboard_stats(user_id)
    recent_parcels = get_customer_parcels(user_id)

    return render_template('customer/dashboard.html',
                           user=user,
                           stats=stats,
                           parcels=recent_parcels[:6])

@customer_bp.route('/book', methods=['GET', 'POST'])
def book():
    user_id = session.get('user_id')
    user = get_user_by_id(user_id)
    locations = get_all_locations()

    if request.method == 'POST':
        receiver_name = request.form.get('receiver_name', '').strip()
        receiver_phone = request.form.get('receiver_phone', '').strip()
        receiver_address = request.form.get('receiver_address', '').strip()
        receiver_city = request.form.get('receiver_city', '').strip()
        parcel_type = request.form.get('parcel_type', 'Standard')
        weight_str = request.form.get('weight', '1.0')
        description = request.form.get('description', '').strip()
        location_id = request.form.get('location_id')
        expected_delivery = request.form.get('expected_delivery')

        try:
            weight = float(weight_str)
            if weight <= 0:
                raise ValueError()
        except ValueError:
            flash("Please enter a valid positive weight in kilograms.", "danger")
            return render_template('customer/book.html', user=user, locations=locations, form_data=request.form)

        if not (receiver_name and receiver_address):
            flash("Receiver name and delivery address are required.", "danger")
            return render_template('customer/book.html', user=user, locations=locations, form_data=request.form)

        # Expected delivery default (3 days ahead if not provided)
        if not expected_delivery:
            expected_delivery = (datetime.date.today() + datetime.timedelta(days=3)).isoformat()

        # Calculate amount
        amount = calculate_parcel_amount(weight, parcel_type)
        tracking_number = generate_tracking_number()

        parcel_data = {
            'tracking_number': tracking_number,
            'customer_id': user_id,
            'sender_name': user['name'],
            'sender_phone': user.get('phone', ''),
            'receiver_name': receiver_name,
            'receiver_phone': receiver_phone,
            'receiver_address': receiver_address,
            'receiver_city': receiver_city,
            'parcel_type': parcel_type,
            'weight': weight,
            'description': description,
            'expected_delivery': expected_delivery,
            'current_location_id': int(location_id) if location_id else None,
            'amount': amount,
            'payment_status': 'Pending'
        }

        try:
            parcel_id = create_parcel_with_tracking_transaction(
                parcel_data,
                initial_remark=f"Consignment booked by customer. Awaiting pickup."
            )
            flash(f"Parcel booked successfully! Your tracking number is: {tracking_number}", "success")
            return redirect(url_for('customer.parcel_details', id=parcel_id))
        except Exception as e:
            flash(f"Booking failed due to an error: {str(e)}", "danger")
            return render_template('customer/book.html', user=user, locations=locations, form_data=request.form)

    return render_template('customer/book.html', user=user, locations=locations)

@customer_bp.route('/calculate-rate', methods=['POST'])
def calculate_rate():
    data = request.get_json() or {}
    weight = data.get('weight', 1.0)
    parcel_type = data.get('parcel_type', 'Standard')
    amount = calculate_parcel_amount(weight, parcel_type)
    return jsonify({"amount": amount})

@customer_bp.route('/parcels')
def parcels():
    user_id = session.get('user_id')
    search = request.args.get('search', '').strip()
    status = request.args.get('status', 'All')

    user_parcels = get_customer_parcels(user_id, search=search, status=status)
    return render_template('customer/parcels.html', parcels=user_parcels, search=search, current_status=status)

@customer_bp.route('/parcels/<int:id>')
def parcel_details(id):
    user_id = session.get('user_id')
    parcel = get_parcel_by_id(id)

    # Ensure parcel belongs to this customer
    if not parcel or parcel['customer_id'] != user_id:
        flash("Parcel not found or access denied.", "danger")
        return redirect(url_for('customer.parcels'))

    history = get_tracking_history(id)
    return render_template('customer/parcel_details.html', parcel=parcel, history=history)

@customer_bp.route('/profile', methods=['GET', 'POST'])
def profile():
    user_id = session.get('user_id')
    user = get_user_by_id(user_id)

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        phone = request.form.get('phone', '').strip()
        address = request.form.get('address', '').strip()

        if not name:
            flash("Name cannot be empty.", "danger")
        else:
            update_user_profile(user_id, name, phone, address)
            session['name'] = name
            flash("Profile updated successfully.", "success")
            return redirect(url_for('customer.profile'))

    return render_template('customer/profile.html', user=user)
