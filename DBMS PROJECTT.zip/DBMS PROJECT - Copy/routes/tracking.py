from flask import Blueprint, render_template, request, flash
from database.queries import get_parcel_by_tracking_number, get_tracking_history

tracking_bp = Blueprint('tracking', __name__)

@tracking_bp.route('/track')
def track():
    tracking_number = request.args.get('tracking_number') or request.args.get('id', '')
    tracking_number = tracking_number.strip()
    
    parcel = None
    history = []

    if tracking_number:
        parcel = get_parcel_by_tracking_number(tracking_number)
        if parcel:
            history = get_tracking_history(parcel['parcel_id'])
        else:
            flash(f"Tracking number '{tracking_number}' not found. Please verify the ID and try again.", "warning")

    return render_template('track.html', tracking_number=tracking_number, parcel=parcel, history=history)
