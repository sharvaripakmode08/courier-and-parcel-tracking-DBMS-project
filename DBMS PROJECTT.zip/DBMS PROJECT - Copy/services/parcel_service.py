"""
Parcel Service for generating tracking IDs, rate estimation, and booking execution.
"""

import datetime
import random
from database.connection import execute_read_one
from database.queries import create_parcel_with_tracking_transaction

def generate_tracking_number():
    """
    Generates a unique tracking number in format CRX + YYYYMMDD + 4 digits.
    Guarantees uniqueness against the parcels table.
    """
    today_str = datetime.date.today().strftime("%Y%m%d")
    
    for _ in range(50):
        seq = random.randint(1001, 9999)
        tracking_no = f"CRX{today_str}{seq}"
        
        # Check database uniqueness
        existing = execute_read_one("SELECT parcel_id FROM parcels WHERE tracking_number = %s", (tracking_no,))
        if not existing:
            return tracking_no

    # Microsecond fallback
    micro = datetime.datetime.now().strftime("%f")[:4]
    return f"CRX{today_str}{micro}"

def calculate_parcel_amount(weight, parcel_type='Standard'):
    """
    Simple transparent rate formula:
    Base Rate + (Weight * 40)
    """
    try:
        w = float(weight)
        if w <= 0:
            w = 1.0
    except (ValueError, TypeError):
        w = 1.0

    base_rates = {
        'Standard': 100.0,
        'Express Priority': 200.0,
        'Fragile Goods': 250.0,
        'Documents': 80.0,
        'Electronics': 180.0,
        'Heavy Cargo': 350.0
    }
    base = base_rates.get(parcel_type, 100.0)
    total = base + (w * 40.0)
    return round(total, 2)
