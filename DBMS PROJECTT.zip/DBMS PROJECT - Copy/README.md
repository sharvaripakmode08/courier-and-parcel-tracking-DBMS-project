# Courier & Parcel Tracking System - College DBMS Project

A clean, comprehensive, fully functional **Courier and Parcel Tracking System** developed as an academic **Database Management Systems (DBMS)** project. Built with Python 3, Flask, Bootstrap 5, and MySQL 8.x relational database engine.

---

## 🎯 Project Overview & Scope Simplification

This application has been refactored and simplified specifically for college DBMS demonstrations and viva presentations:
* **Strict Two-Role Architecture**:
  1. **CUSTOMER**: Registers, books parcels with automatic tracking numbers, views booking history, tracks parcels chronologically, and updates profile.
  2. **COMPANY**: Central management account that monitors all parcels, updates parcel transit status and current hub location, logs tracking checkpoints, edits parcel details, and accesses the interactive DBMS evaluation console.
* **4 Normalized Core Tables**:
  - `users`: Customer and Company credentials and contact details.
  - `locations`: Regional sorting hubs and distribution facilities.
  - `parcels`: Consignments with sender/receiver details, specs, status, location, amount, and payment status.
  - `tracking`: Chronological audit trail logging status transitions, hub locations, and timestamps.
* **1 Relational Database View**: `parcel_tracking_view` joining parcels, customers, and hubs.
* **ACID Transactions**: Consignment booking executes an atomic multi-table transaction across `parcels` and `tracking` with automatic rollback on error.
* **No ORM**: All database interactions use direct, parameterized SQL queries via `mysql-connector-python` to prevent SQL injection and showcase raw DBMS capabilities.

---

## 📊 Entity-Relationship (ER) Diagram

```mermaid
erDiagram
    users ||--o{ parcels : "books (customer_id)"
    locations ||--o{ parcels : "current_location (current_location_id)"
    locations ||--o{ tracking : "checkpoint_location (location_id)"
    parcels ||--o{ tracking : "has audit history (parcel_id)"

    users {
        int user_id PK
        varchar name
        varchar email UK
        varchar password_hash
        enum role "customer, company"
        varchar phone
        text address
        timestamp created_at
    }

    locations {
        int location_id PK
        varchar location_name
        varchar city
        decimal latitude
        decimal longitude
        timestamp created_at
    }

    parcels {
        int parcel_id PK
        varchar tracking_number UK
        int customer_id FK
        varchar sender_name
        varchar sender_phone
        varchar receiver_name
        varchar receiver_phone
        text receiver_address
        varchar receiver_city
        varchar parcel_type
        decimal weight
        text description
        timestamp booking_date
        date expected_delivery
        enum current_status "Booked, In Transit, At Hub, Out for Delivery, Delivered, Cancelled"
        int current_location_id FK
        decimal amount
        enum payment_status "Pending, Paid, Refunded"
        timestamp created_at
        timestamp updated_at
    }

    tracking {
        int tracking_id PK
        int parcel_id FK
        int location_id FK
        enum status "Booked, In Transit, At Hub, Out for Delivery, Delivered, Cancelled"
        text remarks
        timestamp updated_at
    }
```

---

## 🗄️ Relational Database Schema (`courier_db`)

The database design adheres to **Third Normal Form (3NF)**:

| Table Name | Primary Key | Foreign Keys | Key Constraints & Indexes |
|---|---|---|---|
| **`users`** | `user_id` (AUTO_INCREMENT) | None | `email` UNIQUE, `role` ENUM('customer', 'company') |
| **`locations`** | `location_id` (AUTO_INCREMENT) | None | `location_name` VARCHAR(100), `city` VARCHAR(100) |
| **`parcels`** | `parcel_id` (AUTO_INCREMENT) | `customer_id` &rarr; `users(user_id)`, `current_location_id` &rarr; `locations(location_id)` | `tracking_number` UNIQUE, `weight > 0`, `amount >= 0`, `ON DELETE CASCADE` |
| **`tracking`** | `tracking_id` (AUTO_INCREMENT) | `parcel_id` &rarr; `parcels(parcel_id)`, `location_id` &rarr; `locations(location_id)` | `ON DELETE CASCADE`, indexed on `parcel_id` and `updated_at` |

### Database View: `parcel_tracking_view`
```sql
CREATE OR REPLACE VIEW parcel_tracking_view AS
SELECT 
    p.parcel_id,
    p.tracking_number,
    u.name AS customer_name,
    u.email AS customer_email,
    u.phone AS customer_phone,
    p.receiver_name,
    p.receiver_phone,
    p.receiver_address,
    p.receiver_city,
    p.parcel_type,
    p.weight,
    p.current_status,
    COALESCE(l.location_name, 'Origin Hub') AS current_location,
    COALESCE(l.city, 'Regional Corridor') AS current_city,
    p.booking_date,
    p.expected_delivery,
    p.amount,
    p.payment_status
FROM parcels p
INNER JOIN users u ON p.customer_id = u.user_id
LEFT JOIN locations l ON p.current_location_id = l.location_id;
```

---

## 🛠️ Technology Stack

* **Backend Framework**: Python 3.13, Flask 3.1
* **Database Engine**: MySQL Server 8.0.46 (InnoDB Engine, Port 3307)
* **Database Driver**: `mysql-connector-python`
* **Frontend**: HTML5, Jinja2 Templates, Bootstrap 5.3, Bootstrap Icons
* **Security**: Werkzeug Security password hashing (`pbkdf2:sha256`)

---

## 🔑 Demonstration Accounts

| Account Type | Email | Password | Responsibilities & Capabilities |
|---|---|---|---|
| **Company** | `company@courier.com` | `Company@123` | Operations Dashboard, Manage all parcels, Update tracking & hub locations, Edit parcel records, Delete parcels, DBMS Live Evaluation Console (`/company/dbms`). |
| **Customer** | `rahul.sharma@gmail.com` | `Customer@123` | Customer Dashboard, Book new consignments (ACID transaction), Track parcels, View parcel details & invoices, Update profile. |
| **Public** | N/A | N/A | Track parcel by waybill number via `/track`. |

*(Convenient one-click demo credentials autofill buttons are built directly into the login screen).*

---

## 🚀 Setup & Execution Guide

### 1. Configuration (`.env`)
Ensure `.env` in the project root specifies your MySQL credentials:
```env
DB_HOST=localhost
DB_PORT=3307
DB_USER=root
DB_PASSWORD=your_mysql_root_password
DB_NAME=courier_db
SECRET_KEY=courier_tracking_secret_key_2026
```

### 2. Verify Database Connection
```bash
python test_connection.py
```
*Expected Output: `MySQL Version: 8.0.46 | Connection: SUCCESS`*

### 3. Initialize & Seed Database
```bash
python -m database.init_db
python -m database.seed
```

### 4. Run the Application
```bash
python app.py
```
Open your browser and navigate to: **`http://127.0.0.1:5000`**

---

## 🧪 Automated Testing Suite (18 Scenarios)

The test suite runs 18 automated test cases covering end-to-end functionality, SQL queries, transactions, and role enforcement:

```bash
python tests/test_system.py
```

### Verified Test Cases:
1. `test_01_db_connection_and_schema`: Verifies active MySQL connection and existence of the 4 tables + 1 view.
2. `test_02_customer_registration`: Tests customer sign-up and password hashing into `users`.
3. `test_03_customer_login`: Tests customer authentication and redirect to `/customer/dashboard`.
4. `test_04_company_login`: Tests company authentication and redirect to `/company/dashboard`.
5. `test_05_parcel_booking_acid_transaction`: Tests atomic insertion into `parcels` and `tracking`.
6. `test_06_tracking_history_generated_automatically`: Verifies initial checkpoint creation.
7. `test_07_company_views_all_parcels`: Verifies company access to all consignments across customers.
8. `test_08_company_updates_parcel_status`: Verifies company updating parcel status and creating audit record.
9. `test_09_company_updates_parcel_location`: Verifies updating parcel's current distribution hub.
10. `test_10_customer_sees_updated_status`: Verifies customer dashboard and details reflect status change.
11. `test_11_public_track_page`: Verifies public `/track` endpoint displays full chronological history.
12. `test_12_search_parcels`: Tests search across tracking numbers, customers, and cities.
13. `test_13_update_parcel_details`: Tests SQL `UPDATE` statement modifying receiver details and amounts.
14. `test_14_delete_parcel`: Tests SQL `DELETE` statement with cascading cleanup.
15. `test_15_view_query`: Tests querying `parcel_tracking_view`.
16. `test_16_join_query_verification`: Tests multi-table `INNER JOIN` and `LEFT JOIN` relational integrity.
17. `test_17_groupby_aggregate_query`: Tests `GROUP BY` with `COUNT(*)`, `SUM()`, and `AVG()`.
18. `test_18_transaction_rollback`: Tests simulated error triggering `conn.rollback()` with zero orphaned records.

---

## 🎓 College Viva & Examination Reference

### Q1: What makes this a relational database?
**Answer**: Data is organized into 4 separate tables representing entities (`users`, `locations`, `parcels`, `tracking`) connected via Primary Keys and Foreign Keys (`customer_id`, `current_location_id`, `parcel_id`, `location_id`). Referential integrity is enforced with `ON DELETE CASCADE`.

### Q2: What normal form is the schema in?
**Answer**: **Third Normal Form (3NF)**:
- **1NF**: All column values are atomic (e.g., individual tracking numbers, coordinates, timestamps), and each table has a primary key.
- **2NF**: It is in 1NF and all non-key attributes are fully functionally dependent on the primary key (no partial dependencies).
- **3NF**: It is in 2NF and there are no transitive dependencies; non-key attributes depend only on the primary key (customer details are stored in `users`, hub details in `locations`, not repeated inside `parcels`).

### Q3: How are ACID transactions implemented?
**Answer**: When a parcel is booked:
1. `conn.autocommit = False`
2. `INSERT INTO parcels (...)` generates the parcel ID.
3. `INSERT INTO tracking (parcel_id, ...)` logs the initial 'Booked' checkpoint.
4. `conn.commit()` persists both operations atomically.
5. If any exception occurs between steps 2 and 3, `conn.rollback()` executes, ensuring zero partial or orphaned records.

### Q4: Why use a Database View (`parcel_tracking_view`)?
**Answer**: A View encapsulates complex SQL queries (joining `parcels`, `users`, and `locations`) into a reusable virtual table. It simplifies application queries (`SELECT * FROM parcel_tracking_view`), abstracts schema details, and improves maintainability.

### Q5: How is SQL Injection prevented?
**Answer**: Every query in `database/queries.py` uses parameterized queries (`%s` placeholders passed as a tuple parameter to `cursor.execute(query, params)`). The MySQL driver escapes and treats inputs strictly as literal data, preventing injection attacks.
